package com.gfa.tinderclone.models;

public enum Gender {
    MALE, FEMALE;
}
