package com.gfa.tinderclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TinderCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(TinderCloneApplication.class, args);
	}

}
